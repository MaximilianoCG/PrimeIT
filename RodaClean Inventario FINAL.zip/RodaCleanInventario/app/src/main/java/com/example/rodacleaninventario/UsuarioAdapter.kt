package com.example.rodacleaninventario

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.rodacleaninventario.databinding.ItemUsuarioBinding

class UsuarioAdapter(
    private var usuarios: List<Usuario>,
    private val onCheckedChange: (Int, Boolean) -> Unit
) : RecyclerView.Adapter<UsuarioAdapter.UsuarioViewHolder>() {

    private var usuariosFiltrados: List<Usuario> = usuarios
    private val checkedPositions = mutableSetOf<Int>()

    inner class UsuarioViewHolder(private val binding: ItemUsuarioBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(usuario: Usuario, position: Int) {
            binding.tvId.text = usuario.id.toString()
            binding.tvNombre.text = usuario.nombreCompleto
            binding.tvCorreo.text = usuario.correo
            binding.tvRol.text = usuario.rol

            // Color según el rol
            binding.tvRol.setTextColor(
                when (usuario.rol.lowercase()) {
                    "admin" -> 0xFF2AC185.toInt()      // Verde corporativo
                    "supervisor" -> 0xFF2196F3.toInt() // Azul
                    else -> 0xFF555555.toInt()         // Gris oscuro
                }
            )

            // Estado del checkbox
            binding.checkboxSeleccionar.isChecked = checkedPositions.contains(position)

            // Click en checkbox
            binding.checkboxSeleccionar.setOnCheckedChangeListener { _, isChecked ->
                updateSelection(position, isChecked, usuario.id)
            }

            // Click en toda la fila
            binding.root.setOnClickListener {
                val newChecked = !binding.checkboxSeleccionar.isChecked
                binding.checkboxSeleccionar.isChecked = newChecked
                updateSelection(position, newChecked, usuario.id)
            }

            binding.root.isClickable = true
            binding.root.isFocusable = true
        }

        private fun updateSelection(position: Int, isChecked: Boolean, id: Int) {
            if (isChecked) {
                checkedPositions.add(position)
            } else {
                checkedPositions.remove(position)
            }
            onCheckedChange(id, isChecked)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UsuarioViewHolder {
        val binding = ItemUsuarioBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return UsuarioViewHolder(binding)
    }

    override fun onBindViewHolder(holder: UsuarioViewHolder, position: Int) {
        holder.bind(usuariosFiltrados[position], position)
    }

    override fun getItemCount(): Int = usuariosFiltrados.size

    // ==================== FILTRO ====================
    fun filter(query: String) {
        if (query.isBlank()) {
            usuariosFiltrados = usuarios
        } else {
            val lowerQuery = query.lowercase()
            usuariosFiltrados = usuarios.filter { usuario ->
                usuario.nombreCompleto.lowercase().contains(lowerQuery) ||
                        usuario.correo.lowercase().contains(lowerQuery) ||
                        usuario.id.toString().contains(lowerQuery) ||
                        usuario.rol.lowercase().contains(lowerQuery)
            }
        }
        notifyDataSetChanged()
    }

    // ==================== USUARIOS SELECCIONADOS ====================
    fun getSelectedUsuarios(): List<Usuario> {
        return checkedPositions.mapNotNull { position ->
            if (position < usuariosFiltrados.size) usuariosFiltrados[position] else null
        }
    }
}