package com.example.rodacleaninventario

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.rodacleaninventario.databinding.ActivityPerfilBinding
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.Timestamp
import java.text.SimpleDateFormat
import java.util.Locale

class PerfilActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPerfilBinding
    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        try {
            binding = ActivityPerfilBinding.inflate(layoutInflater)
            setContentView(binding.root)

            setSupportActionBar(binding.toolbar)

            binding.toolbar.setNavigationOnClickListener {
                regresarSegunRol()
            }

            cargarDatosPerfil()

        } catch (e: Exception) {
            Toast.makeText(this, "Error al cargar Perfil: ${e.message}", Toast.LENGTH_LONG).show()
            e.printStackTrace()
        }
    }

    private fun regresarSegunRol() {
        val prefs = getSharedPreferences("app_prefs", MODE_PRIVATE)
        val rol = prefs.getString("user_rol", "")?.lowercase()

        when (rol) {
            "admin" -> {
                startActivity(Intent(this, UsuarioActivity::class.java))
            }
            "accessadmin", "admin_usuarios" -> {
                startActivity(Intent(this, AccessAdminActivity::class.java))
            }
            else -> {
                startActivity(Intent(this, VistaUsuarioActivity::class.java))
            }
        }

        finish()
    }

    private fun cargarDatosPerfil() {
        val prefs = getSharedPreferences("app_prefs", MODE_PRIVATE)
        val documentId = prefs.getString("user_document_id", null)

        if (documentId.isNullOrEmpty()) {
            Toast.makeText(this, "No se encontró información de sesión", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        db.collection("usuarios")
            .document(documentId)
            .get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val usuario = document.toObject(Usuario::class.java)

                    if (usuario != null) {
                        binding.tvNombre.text = usuario.nombreCompleto
                        binding.tvCorreo.text = usuario.correo
                        binding.tvOrganizacion.text = usuario.organizacion
                        binding.tvPuesto.text = usuario.puesto
                        binding.tvContacto.text = usuario.telefono
                        binding.tvFechaNacimiento.text = formatTimestamp(usuario.fechaNacimiento)
                        binding.tvGerente.text = usuario.gerenteAsignado.ifEmpty { "No asignado" }
                    }
                } else {
                    Toast.makeText(this, "Usuario no encontrado", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error al cargar perfil: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun formatTimestamp(timestamp: Timestamp?): String {
        if (timestamp == null) return "No registrado"
        val sdf = SimpleDateFormat("dd 'de' MMMM 'de' yyyy", Locale("es", "ES"))
        return sdf.format(timestamp.toDate())
    }
}