package com.example.rodacleaninventario

import android.app.Activity
import android.widget.TextView
import com.google.android.material.navigation.NavigationView
import com.google.firebase.firestore.FirebaseFirestore

object SessionUtils {

    fun cargarHeaderUsuario(activity: Activity, navView: NavigationView) {

        val headerView = navView.getHeaderView(0)

        val tvNombre = headerView.findViewById<TextView>(R.id.tvNombreHeader)
        val tvCorreo = headerView.findViewById<TextView>(R.id.tvCorreoHeader)
        val tvOrg = headerView.findViewById<TextView>(R.id.tvOrgHeader)

        val prefs = activity.getSharedPreferences("app_prefs", Activity.MODE_PRIVATE)
        val documentId = prefs.getString("user_document_id", null)

        if (documentId.isNullOrEmpty()) return

        val db = FirebaseFirestore.getInstance()

        db.collection("usuarios")
            .document(documentId)
            .get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val usuario = document.toObject(Usuario::class.java)

                    usuario?.let {
                        tvNombre.text = it.nombreCompleto
                        tvCorreo.text = it.correo
                        tvOrg.text = it.organizacion
                    }
                }
            }
    }
}