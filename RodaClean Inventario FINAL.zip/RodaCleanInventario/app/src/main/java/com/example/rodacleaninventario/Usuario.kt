package com.example.rodacleaninventario

import com.google.firebase.Timestamp

data class Usuario(
    // Datos básicos
    val id: Int = 0,
    val nombre: String = "",
    val apellido: String = "",
    val correo: String = "",
    val telefono: String = "",

    // Información laboral
    val puesto: String = "",
    val rol: String = "Usuario",
    val organizacion: String = "Roda Clean",

    // 🔥 AQUÍ ESTÁ EL FIX
    val fechaNacimiento: Timestamp? = null,
    val gerenteAsignado: String = "",
    val fechaRegistro: Timestamp? = null,
    val password: String = "",

    // ID del documento
    var documentId: String = ""
) {
    constructor() : this(
        0, "", "", "", "", "", "", "", null, "", null, "", ""
    )

    val nombreCompleto: String
        get() = "$nombre $apellido".trim()
}