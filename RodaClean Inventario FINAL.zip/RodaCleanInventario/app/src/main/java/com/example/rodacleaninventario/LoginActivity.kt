package com.example.rodacleaninventario

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.rodacleaninventario.databinding.ActivityLoginBinding
import com.google.firebase.firestore.FirebaseFirestore

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupSpinner()
        setupLoginButton()
    }

    private fun setupSpinner() {
        val organizaciones = arrayOf("Roda Clean", "Tecmilenio")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, organizaciones)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerOrganizacion.adapter = adapter
    }

    private fun setupLoginButton() {
        binding.btnLogin.setOnClickListener {
            if (validarFormulario()) {
                val email = binding.etUsuario.text.toString().trim()
                val password = binding.etPassword.text.toString()
                mostrarCargando(true)
                verificarLogin(email, password)
            }
        }
    }

    private fun validarFormulario(): Boolean {
        var valido = true

        val email = binding.etUsuario.text.toString().trim()
        val password = binding.etPassword.text.toString()

        if (email.isEmpty()) {
            binding.tilUsuario.error = "Correo obligatorio"
            valido = false
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.tilUsuario.error = "Correo inválido"
            valido = false
        } else {
            binding.tilUsuario.error = null
        }

        if (password.isEmpty()) {
            binding.tilPassword.error = "Contraseña obligatoria"
            valido = false
        } else {
            binding.tilPassword.error = null
        }

        return valido
    }

    private fun verificarLogin(email: String, password: String) {
        db.collection("usuarios")
            .whereEqualTo("correo", email)
            .get()
            .addOnSuccessListener { documents ->

                mostrarCargando(false)

                if (documents.isEmpty) {
                    Toast.makeText(this, "Usuario no encontrado", Toast.LENGTH_SHORT).show()
                    return@addOnSuccessListener
                }

                val userDoc = documents.documents[0]

                val usuario = userDoc.toObject(Usuario::class.java)

                if (usuario == null) {
                    Toast.makeText(this, "Error al leer usuario", Toast.LENGTH_SHORT).show()
                    return@addOnSuccessListener
                }

                usuario.documentId = userDoc.id

                if (usuario.password == password) {

                    val prefs = getSharedPreferences("app_prefs", MODE_PRIVATE)
                    prefs.edit()
                        .putString("user_email", email)
                        .putString("user_rol", usuario.rol)
                        .putString("user_document_id", usuario.documentId)
                        .apply()

                    when (usuario.rol.lowercase()) {
                        "admin" -> startActivity(Intent(this, UsuarioActivity::class.java))
                        "accessadmin", "admin_usuarios" -> startActivity(Intent(this, AccessAdminActivity::class.java))
                        else -> startActivity(Intent(this, VistaUsuarioActivity::class.java))
                    }

                    finish()

                } else {
                    Toast.makeText(this, "Contraseña incorrecta", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener {
                mostrarCargando(false)
                Toast.makeText(this, "Error de conexión", Toast.LENGTH_SHORT).show()
            }
    }

    private fun mostrarCargando(mostrar: Boolean) {
        binding.progressBar.visibility = if (mostrar) View.VISIBLE else View.GONE
        binding.btnLogin.visibility = if (mostrar) View.INVISIBLE else View.VISIBLE
        binding.btnLogin.isEnabled = !mostrar
    }
}