package com.example.rodacleaninventario

import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.core.view.GravityCompat
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.rodacleaninventario.databinding.ActivityUsuarioBinding
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FieldValue

class VistaUsuarioActivity : AppCompatActivity() {

    private lateinit var binding: ActivityUsuarioBinding
    private lateinit var productoAdapter: ProductoAdapter
    private val db = FirebaseFirestore.getInstance()

    private val productosList = mutableListOf<Producto>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUsuarioBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayShowTitleEnabled(true)

        binding.toolbar.setNavigationOnClickListener {
            binding.drawerLayout.openDrawer(GravityCompat.START)
        }

        SessionUtils.cargarHeaderUsuario(this, binding.navView)

        setupNavigationDrawer()
        setupRecyclerView()
        setupBottomNavigation()
        setupButtons()

        aplicarPermisosUI()

        cargarProductosDesdeFirestore()
    }

    override fun onResume() {
        super.onResume()
        aplicarPermisosUI()
        cargarProductosDesdeFirestore()
    }

    private fun aplicarPermisosUI() {
        val prefs = getSharedPreferences("app_prefs", MODE_PRIVATE)
        val rol = prefs.getString("user_rol", "") ?: ""

        if (rol.lowercase() == "usuario") {
            binding.btnAgregar.visibility = android.view.View.GONE
        } else {
            binding.btnAgregar.visibility = android.view.View.VISIBLE
        }
    }

    private fun cargarProductosDesdeFirestore() {
        db.collection("productos")
            .get()
            .addOnSuccessListener { result ->
                val nuevaLista = mutableListOf<Producto>()

                for (document in result) {
                    val producto = document.toObject(Producto::class.java)
                    producto.documentId = document.id
                    nuevaLista.add(producto)
                }

                productoAdapter.updateList(nuevaLista)
            }
            .addOnFailureListener {
                Toast.makeText(this, "Error al cargar productos", Toast.LENGTH_SHORT).show()
            }
    }

    private fun setupNavigationDrawer() {
        binding.navView.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.nav_inicio -> { }

                R.id.nav_perfil -> {
                    binding.drawerLayout.closeDrawer(GravityCompat.START)
                    binding.drawerLayout.postDelayed({
                        startActivity(Intent(this, PerfilActivity::class.java))
                    }, 250)
                }

                R.id.nav_config -> {
                    Toast.makeText(this, "Configuración - Próximamente", Toast.LENGTH_SHORT).show()
                }

                R.id.nav_ayuda -> {
                    mostrarPopupAyuda()
                }

                R.id.nav_cerrar_sesion -> {
                    cerrarSesion()
                }
            }
            true
        }
    }

    private fun setupRecyclerView() {
        productoAdapter = ProductoAdapter(productosList) { _, _ -> }

        binding.recyclerProductos.layoutManager = LinearLayoutManager(this)
        binding.recyclerProductos.adapter = productoAdapter
        binding.recyclerProductos.setHasFixedSize(true)

        val divider = DividerItemDecoration(this, LinearLayoutManager.VERTICAL)
        binding.recyclerProductos.addItemDecoration(divider)
    }

    private fun setupBottomNavigation() {
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.nav_dashboard -> {
                    startActivity(Intent(this, DashboardActivity::class.java))
                    true
                }
                R.id.nav_home -> true
                R.id.nav_ayuda -> {
                    mostrarPopupAyuda()
                    true
                }
                else -> false
            }
        }
    }

    private fun setupButtons() {
        binding.btnRestar.setOnClickListener {
            val seleccionados = productoAdapter.getSelectedProductos()

            if (seleccionados.isEmpty()) {
                Toast.makeText(this, "Selecciona al menos un producto", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val itemsARestar = seleccionados.map { ProductoARestar(it, 1) }.toMutableList()
            mostrarDialogoRestarProductos(itemsARestar)
        }

        binding.btnAgregar.setOnClickListener {
            startActivity(Intent(this, AgregarProductoActivity::class.java))
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.toolbar_menu, menu)

        val searchItem = menu.findItem(R.id.action_search)
        val searchView = searchItem.actionView as SearchView

        searchView.queryHint = "Buscar productos..."

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean = false

            override fun onQueryTextChange(newText: String?): Boolean {
                productoAdapter.filter(newText.orEmpty())
                return true
            }
        })

        return true
    }

    private fun mostrarDialogoRestarProductos(items: MutableList<ProductoARestar>) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_restar_productos, null)

        val recyclerRestar = dialogView.findViewById<androidx.recyclerview.widget.RecyclerView>(R.id.recyclerRestar)
        val btnConfirmar = dialogView.findViewById<com.google.android.material.button.MaterialButton>(R.id.btnConfirmarResta)
        val btnCancelar = dialogView.findViewById<com.google.android.material.button.MaterialButton>(R.id.btnCancelarResta)

        val adapter = RestarProductoAdapter(items) {}

        recyclerRestar.layoutManager = LinearLayoutManager(this)
        recyclerRestar.adapter = adapter

        val dialog = AlertDialog.Builder(this)
            .setView(dialogView)
            .create()

        btnConfirmar.setOnClickListener {
            val itemsFinales = adapter.getItemsToRestar()
            if (itemsFinales.isEmpty()) {
                Toast.makeText(this, "No hay productos para restar", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            mostrarConfirmacionFinal(itemsFinales)
            dialog.dismiss()
        }

        btnCancelar.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun mostrarConfirmacionFinal(items: List<ProductoARestar>) {
        val mensaje = buildString {
            append("¿Estás seguro?\n\n")
            items.forEach {
                append("- ${it.producto.nombre}: ${it.cantidadARestar}\n")
            }
        }

        AlertDialog.Builder(this)
            .setTitle("Confirmación")
            .setMessage(mensaje)
            .setPositiveButton("Sí") { _, _ ->
                realizarRestaRealEnFirestore(items)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun realizarRestaRealEnFirestore(items: List<ProductoARestar>) {
        val batch = db.batch()

        items.forEach {
            val docRef = db.collection("productos").document(it.producto.documentId)
            batch.update(docRef, "cantidad", FieldValue.increment(-it.cantidadARestar.toLong()))
        }

        batch.commit()
            .addOnSuccessListener {
                Toast.makeText(this, "Actualizado", Toast.LENGTH_SHORT).show()
                cargarProductosDesdeFirestore()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show()
            }
    }

    private fun mostrarPopupAyuda() {
        AlertDialog.Builder(this)
            .setTitle("Ayuda")
            .setMessage("Contacto: 8181818181")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun cerrarSesion() {
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}