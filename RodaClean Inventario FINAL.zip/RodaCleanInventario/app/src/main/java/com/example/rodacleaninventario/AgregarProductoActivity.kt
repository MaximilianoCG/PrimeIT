package com.example.rodacleaninventario

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.rodacleaninventario.databinding.ActivityAgregarProductoBinding
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FieldValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class AgregarProductoActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAgregarProductoBinding
    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAgregarProductoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupButtons()
        cargarProductosAutocomplete() // 🔥 NUEVO
    }

    private fun setupButtons() {
        binding.btnGuardar.setOnClickListener {
            val nombre = binding.etNombre.text.toString().trim()
            val precioStr = binding.etPrecio.text.toString().trim()
            val cantidadStr = binding.etCantidad.text.toString().trim()

            if (nombre.isEmpty() || precioStr.isEmpty() || cantidadStr.isEmpty()) {
                Toast.makeText(this, "Todos los campos son obligatorios", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val precio = precioStr.toDoubleOrNull() ?: 0.0
            val cantidad = cantidadStr.toIntOrNull() ?: 0

            if (precio <= 0 || cantidad <= 0) {
                Toast.makeText(this, "Precio y cantidad deben ser mayores a 0", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            guardarProducto(nombre, precio, cantidad)
        }

        binding.btnCancelar.setOnClickListener {
            finish()
        }
    }

    // 🔥 AUTOCOMPLETE
    private fun cargarProductosAutocomplete() {
        db.collection("productos")
            .get()
            .addOnSuccessListener { result ->

                val nombres = result.mapNotNull { it.getString("nombre") }

                val adapter = ArrayAdapter(
                    this,
                    android.R.layout.simple_dropdown_item_1line,
                    nombres
                )

                binding.etNombre.setAdapter(adapter)

                // 👉 cuando selecciona uno
                binding.etNombre.setOnItemClickListener { parent, _, position, _ ->
                    val nombreSeleccionado = parent.getItemAtPosition(position).toString()

                    db.collection("productos")
                        .whereEqualTo("nombre", nombreSeleccionado)
                        .get()
                        .addOnSuccessListener { res ->
                            if (!res.isEmpty) {
                                val producto = res.documents[0].toObject(Producto::class.java)

                                producto?.let {
                                    binding.etPrecio.setText(it.precio.toString())
                                }
                            }
                        }
                }
            }
    }

    // 🔥 LÓGICA INTELIGENTE
    private fun guardarProducto(nombre: String, precio: Double, cantidad: Int) {
        CoroutineScope(Dispatchers.Main).launch {
            try {

                val query = db.collection("productos")
                    .whereEqualTo("nombre", nombre)
                    .get()
                    .await()

                if (!query.isEmpty) {
                    // ✅ SUMAR STOCK
                    val doc = query.documents[0]

                    db.collection("productos")
                        .document(doc.id)
                        .update("cantidad", FieldValue.increment(cantidad.toLong()))
                        .addOnSuccessListener {
                            Toast.makeText(this@AgregarProductoActivity,
                                "Stock actualizado", Toast.LENGTH_SHORT).show()
                            finish()
                        }

                } else {
                    // 🆕 CREAR NUEVO
                    val nuevoId = obtenerSiguienteIdProducto()

                    val nuevoProducto = Producto(
                        id = nuevoId,
                        nombre = nombre,
                        cantidad = cantidad,
                        precio = precio
                    )

                    db.collection("productos")
                        .document(nuevoId.toString())
                        .set(nuevoProducto)
                        .addOnSuccessListener {
                            Toast.makeText(this@AgregarProductoActivity,
                                "Producto creado con ID: $nuevoId", Toast.LENGTH_LONG).show()
                            finish()
                        }
                }

            } catch (e: Exception) {
                Toast.makeText(this@AgregarProductoActivity,
                    "Error: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private suspend fun obtenerSiguienteIdProducto(): Int {
        val counterRef = db.collection("contadores").document("producto_id")

        return db.runTransaction { transaction ->
            val snapshot = transaction.get(counterRef)
            val currentId = snapshot.getLong("ultimo_id")?.toInt() ?: 0
            val nextId = currentId + 1

            if (!snapshot.exists()) {
                transaction.set(counterRef, mapOf("ultimo_id" to nextId))
            } else {
                transaction.update(counterRef, "ultimo_id", nextId)
            }

            nextId
        }.await()
    }

    override fun onSupportNavigateUp(): Boolean {
        val prefs = getSharedPreferences("app_prefs", MODE_PRIVATE)
        val userRol = prefs.getString("user_rol", "Usuario")?.lowercase()

        when (userRol) {
            "admin" -> {
                val intent = Intent(this, UsuarioActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
            }
            "accessadmin", "admin_usuarios" -> {
                val intent = Intent(this, AccessAdminActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
            }
            else -> {
                val intent = Intent(this, VistaUsuarioActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
            }
        }
        finish()
        return true
    }
}