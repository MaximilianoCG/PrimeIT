package com.example.rodacleaninventario

data class Producto(
    val id: Int = 0,
    val nombre: String = "",
    val cantidad: Int = 0,
    val precio: Double = 0.0,
    var documentId: String = ""
) {
    constructor() : this(0, "", 0, 0.0, "")
}

data class ProductoARestar(
    val producto: Producto,
    var cantidadARestar: Int = 1
)