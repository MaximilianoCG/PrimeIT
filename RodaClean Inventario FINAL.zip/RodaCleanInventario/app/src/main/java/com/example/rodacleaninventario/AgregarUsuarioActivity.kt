package com.example.rodacleaninventario

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.rodacleaninventario.databinding.ActivityAgregarUsuarioBinding
import com.google.firebase.Timestamp
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class AgregarUsuarioActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAgregarUsuarioBinding
    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAgregarUsuarioBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupSpinnerRol()
        setupButtons()
    }

    private fun setupSpinnerRol() {
        val roles = listOf("Usuario", "Supervisor", "Admin", "AccessAdmin")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, roles)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerRol.adapter = adapter
    }

    private fun setupButtons() {
        binding.btnGuardarUsuario.setOnClickListener {

            val nombre = binding.etNombre.text.toString().trim()
            val apellido = binding.etApellido.text.toString().trim()
            val correo = binding.etCorreo.text.toString().trim()
            val telefono = binding.etTelefono.text.toString().trim()
            val puesto = binding.etPuesto.text.toString().trim()
            val rol = binding.spinnerRol.selectedItem.toString()
            val password = binding.etPassword.text.toString().trim()

            if (nombre.isEmpty() || apellido.isEmpty() || correo.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Nombre, Apellido, Correo y Contraseña son obligatorios", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (password.length < 6) {
                Toast.makeText(this, "La contraseña debe tener al menos 6 caracteres", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            guardarUsuarioConIdSecuencial(
                nombre, apellido, correo, telefono, puesto, rol, password
            )
        }

        binding.btnCancelar.setOnClickListener {
            finish()
        }
    }

    private fun guardarUsuarioConIdSecuencial(
        nombre: String,
        apellido: String,
        correo: String,
        telefono: String,
        puesto: String,
        rol: String,
        password: String
    ) {
        CoroutineScope(Dispatchers.Main).launch {
            try {

                val nuevoId = obtenerSiguienteIdUsuario()

                val nuevoUsuario = Usuario(
                    id = nuevoId,
                    nombre = nombre,
                    apellido = apellido,
                    correo = correo,
                    telefono = telefono,
                    puesto = puesto,
                    rol = rol,
                    organizacion = "Roda Clean",
                    password = password,

                    // 🔥 FIX AQUÍ
                    fechaNacimiento = null, // si no lo usas aún
                    gerenteAsignado = "",
                    fechaRegistro = Timestamp.now() // ← CORRECTO
                )

                db.collection("usuarios")
                    .document(nuevoId.toString())
                    .set(nuevoUsuario)
                    .addOnSuccessListener {
                        Toast.makeText(
                            this@AgregarUsuarioActivity,
                            "Usuario creado correctamente con ID: $nuevoId",
                            Toast.LENGTH_LONG
                        ).show()
                        finish()
                    }
                    .addOnFailureListener { e ->
                        Toast.makeText(
                            this@AgregarUsuarioActivity,
                            "Error al guardar: ${e.message}",
                            Toast.LENGTH_LONG
                        ).show()
                    }

            } catch (e: Exception) {
                Toast.makeText(this@AgregarUsuarioActivity, "Error: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private suspend fun obtenerSiguienteIdUsuario(): Int {
        val counterRef = db.collection("contadores").document("usuario_id")

        return db.runTransaction { transaction ->
            val snapshot = transaction.get(counterRef)
            val currentId = snapshot.getLong("ultimo_id")?.toInt() ?: 0
            val nextId = currentId + 1

            if (!snapshot.exists()) {
                transaction.set(counterRef, mapOf("ultimo_id" to nextId))
            } else {
                transaction.update(counterRef, "ultimo_id", nextId)
            }

            nextId
        }.await()
    }

    override fun onSupportNavigateUp(): Boolean {
        val prefs = getSharedPreferences("app_prefs", MODE_PRIVATE)
        val userRol = prefs.getString("user_rol", "Usuario")?.lowercase()

        when (userRol) {
            "admin" -> {
                // Si eres Admin, regresa a UsuarioActivity (gestión de productos)
                val intent = Intent(this, UsuarioActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
            }
            "accessadmin", "admin_usuarios" -> {
                // Si eres AccessAdmin, regresa a AccessAdminActivity
                val intent = Intent(this, AccessAdminActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
            }
            else -> {
                // Usuario normal → regresa a VistaUsuarioActivity
                val intent = Intent(this, VistaUsuarioActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP
                startActivity(intent)
            }
        }
        finish()
        return true
    }
}