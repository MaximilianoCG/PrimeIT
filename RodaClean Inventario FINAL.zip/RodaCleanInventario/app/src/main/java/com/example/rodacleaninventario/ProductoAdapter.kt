package com.example.rodacleaninventario

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.rodacleaninventario.databinding.ItemProductoBinding

class ProductoAdapter(
    private var productos: List<Producto>,
    private val onCheckedChange: (Int, Boolean) -> Unit
) : RecyclerView.Adapter<ProductoAdapter.ProductoViewHolder>() {

    private var productosFiltrados: List<Producto> = productos
    private val checkedPositions = mutableSetOf<Int>()

    inner class ProductoViewHolder(private val binding: ItemProductoBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(producto: Producto, position: Int) {
            binding.tvId.text = producto.id.toString()
            binding.tvNombre.text = producto.nombre
            binding.tvCantidad.text = producto.cantidad.toString()
            binding.tvPrecio.text = String.format("$%.2f", producto.precio)

            binding.checkboxSeleccionar.isChecked = checkedPositions.contains(position)

            binding.checkboxSeleccionar.setOnCheckedChangeListener { _, isChecked ->
                updateSelection(position, isChecked)
            }

            binding.root.setOnClickListener {
                val newChecked = !binding.checkboxSeleccionar.isChecked
                binding.checkboxSeleccionar.isChecked = newChecked
                updateSelection(position, newChecked)
            }
        }

        private fun updateSelection(position: Int, isChecked: Boolean) {
            if (isChecked) checkedPositions.add(position) else checkedPositions.remove(position)
            onCheckedChange(position, isChecked)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductoViewHolder {
        val binding = ItemProductoBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ProductoViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ProductoViewHolder, position: Int) {
        holder.bind(productosFiltrados[position], position)
    }

    override fun getItemCount() = productosFiltrados.size

    fun filter(query: String) {
        if (query.isBlank()) {
            productosFiltrados = productos
        } else {
            val q = query.lowercase().trim()
            productosFiltrados = productos.filter { producto ->
                producto.id.toString().contains(q) ||
                        producto.nombre.lowercase().contains(q) ||
                        producto.cantidad.toString().contains(q) ||
                        String.format("%.2f", producto.precio).contains(q)
            }
        }
        notifyDataSetChanged()
    }

    fun getSelectedProductos(): List<Producto> {
        return checkedPositions.mapNotNull { pos ->
            if (pos < productosFiltrados.size) productosFiltrados[pos] else null
        }
    }

    // Método útil para refrescar toda la lista desde fuera
    fun updateList(newList: List<Producto>) {
        productos = newList
        productosFiltrados = newList
        checkedPositions.clear()
        notifyDataSetChanged()
    }
}