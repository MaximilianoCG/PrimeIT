package com.example.rodacleaninventario

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.core.view.GravityCompat
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.rodacleaninventario.databinding.ActivityAccessAdminBinding
import com.google.firebase.firestore.FirebaseFirestore

class AccessAdminActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAccessAdminBinding
    private lateinit var usuarioAdapter: UsuarioAdapter
    private val db = FirebaseFirestore.getInstance()
    private val usuariosList = mutableListOf<Usuario>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAccessAdminBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)

        binding.toolbar.setNavigationOnClickListener {
            binding.drawerLayout.openDrawer(GravityCompat.START)
        }

        SessionUtils.cargarHeaderUsuario(this, binding.navView)

        setupNavigationDrawer()
        setupRecyclerView()
        setupBottomNavigation()
        setupButtons()

        binding.bottomNavigation.menu.clear()
        binding.bottomNavigation.inflateMenu(R.menu.bottom_menu_access_admin)

        cargarUsuariosDesdeFirestore()
    }

    private fun cargarUsuariosDesdeFirestore() {
        db.collection("usuarios")
            .get()
            .addOnSuccessListener { result ->
                usuariosList.clear()

                for (document in result) {
                    val usuario = document.toObject(Usuario::class.java)
                    usuario.documentId = document.id
                    usuariosList.add(usuario)
                }

                usuarioAdapter = UsuarioAdapter(usuariosList) { _, _ -> }
                binding.recyclerUsuarios.adapter = usuarioAdapter
            }
            .addOnFailureListener {
                Toast.makeText(this, "Error al cargar usuarios", Toast.LENGTH_SHORT).show()
            }
    }

    // Después de cargarUsuariosDesdeFirestore()
    override fun onResume() {
        super.onResume()
        cargarUsuariosDesdeFirestore()   // Refresca la lista al volver
    }

    private fun setupNavigationDrawer() {
        binding.navView.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {

                R.id.nav_inicio -> {
                    // Ya estamos en AccessAdminActivity → solo cerramos el drawer
                    // No hacemos nada más
                }

                R.id.nav_perfil -> {
                    startActivity(Intent(this, PerfilActivity::class.java))
                }


                R.id.nav_ayuda -> {
                    mostrarPopupAyuda()
                }

                R.id.nav_cerrar_sesion -> {
                    cerrarSesion()
                }
            }

            binding.drawerLayout.closeDrawer(GravityCompat.START)
            true
        }
    }

    private fun setupRecyclerView() {
        binding.recyclerUsuarios.layoutManager = LinearLayoutManager(this)
        binding.recyclerUsuarios.setHasFixedSize(true)

        val divider = DividerItemDecoration(this, LinearLayoutManager.VERTICAL)
        binding.recyclerUsuarios.addItemDecoration(divider)
    }

    private fun setupBottomNavigation() {
        // Marcar "Usuarios" como seleccionado por defecto
        binding.bottomNavigation.post {
            binding.bottomNavigation.selectedItemId = R.id.nav_usuarios
        }

        binding.bottomNavigation.setOnItemSelectedListener { item ->
            when (item.itemId) {

                R.id.nav_dashboard -> {
                    startActivity(Intent(this, DashboardActivity::class.java))
                    true
                }

                R.id.nav_usuarios -> {
                    // Ya estamos aquí → no hacemos nada
                    true
                }

                R.id.nav_ayuda -> {
                    mostrarPopupAyuda()
                    true
                }

                else -> false
            }
        }
    }

    private fun setupButtons() {
        binding.btnAgregarUsuario.setOnClickListener {
            startActivity(Intent(this, AgregarUsuarioActivity::class.java))
        }

        binding.btnEliminarUsuario.setOnClickListener {

            val seleccionados = usuarioAdapter.getSelectedUsuarios()

            if (seleccionados.isEmpty()) {
                Toast.makeText(this, "Selecciona al menos un usuario", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            mostrarConfirmacionEliminacion(seleccionados)
        }
    }

    private fun mostrarConfirmacionEliminacion(usuarios: List<Usuario>) {

        val mensaje = buildString {
            append("¿Eliminar usuarios?\n\n")
            usuarios.forEach {
                append("- ${it.nombreCompleto}\n")
            }
        }

        AlertDialog.Builder(this)
            .setTitle("Confirmación")
            .setMessage(mensaje)
            .setPositiveButton("Eliminar") { _, _ ->
                eliminarUsuarios(usuarios)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun eliminarUsuarios(usuarios: List<Usuario>) {

        val batch = db.batch()

        usuarios.forEach {
            val ref = db.collection("usuarios").document(it.documentId)
            batch.delete(ref)
        }

        batch.commit()
            .addOnSuccessListener {
                Toast.makeText(this, "Usuarios eliminados", Toast.LENGTH_SHORT).show()
                cargarUsuariosDesdeFirestore()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Error al eliminar", Toast.LENGTH_SHORT).show()
            }
    }

    private fun mostrarPopupAyuda() {
        AlertDialog.Builder(this)
            .setTitle("Ayuda")
            .setMessage("Contacto: 8110145920")
            .setPositiveButton("OK", null)
            .show()
    }

    private fun cerrarSesion() {
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }

    override fun onCreateOptionsMenu(menu: android.view.Menu): Boolean {
        menuInflater.inflate(R.menu.toolbar_menu, menu)

        val searchItem = menu.findItem(R.id.action_search)
        val searchView = searchItem.actionView as SearchView

        searchView.queryHint = "Buscar usuario..."

        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean = false

            override fun onQueryTextChange(newText: String?): Boolean {
                usuarioAdapter.filter(newText.orEmpty())
                return true
            }
        })

        return true
    }
}