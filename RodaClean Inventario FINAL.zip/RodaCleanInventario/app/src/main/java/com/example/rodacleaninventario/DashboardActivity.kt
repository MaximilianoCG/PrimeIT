package com.example.rodacleaninventario

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.rodacleaninventario.databinding.ActivityDashboardBinding
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.Calendar

class DashboardActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDashboardBinding
    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        try {
            binding = ActivityDashboardBinding.inflate(layoutInflater)
            setContentView(binding.root)

            setSupportActionBar(binding.toolbar)
            supportActionBar?.setDisplayHomeAsUpEnabled(true)
            supportActionBar?.setDisplayShowHomeEnabled(true)

            cargarDatosDashboard()

        } catch (e: Exception) {
            Toast.makeText(this, "Error al inflar Dashboard: ${e.message}", Toast.LENGTH_LONG).show()
            e.printStackTrace()
        }
    }

    private fun cargarDatosDashboard() {
        CoroutineScope(Dispatchers.Main).launch {
            try {
                val productosSnapshot = db.collection("productos").get().await()
                val totalProductos = productosSnapshot.size()

                var bajoStockCount = 0
                productosSnapshot.forEach { doc ->
                    val cantidad = doc.getLong("cantidad")?.toInt() ?: 0
                    if (cantidad <= 9) bajoStockCount++
                }

                binding.tvTotalProductos.text = totalProductos.toString()
                binding.tvBajoStock.text = bajoStockCount.toString()

                val calendar = Calendar.getInstance()
                calendar.add(Calendar.DAY_OF_YEAR, -7)
                val fechaInicio = calendar.time

                val movimientosSnapshot = db.collection("movimientos")
                    .whereGreaterThanOrEqualTo("fecha", fechaInicio)
                    .whereEqualTo("tipo", "salida")
                    .get()
                    .await()

                var totalSalidas = 0
                var totalIngresos = 0.0
                val mapaProductos = mutableMapOf<String, Int>()

                movimientosSnapshot.forEach { doc ->
                    val cantidad = doc.getLong("cantidad")?.toInt() ?: 0
                    val precio = doc.getDouble("precioUnitario") ?: 0.0
                    val nombre = doc.getString("nombreProducto") ?: "Desconocido"

                    totalSalidas += cantidad
                    totalIngresos += cantidad * precio

                    mapaProductos[nombre] = (mapaProductos[nombre] ?: 0) + cantidad
                }

                val totalSalidasFinal = totalSalidas + bajoStockCount

                binding.tvSalidasSemana.text = "$totalSalidasFinal productos"
                binding.tvIngresosSemana.text = "Ingresos generados: $${String.format("%.2f", totalIngresos)}"

                if (mapaProductos.isEmpty()) {
                    binding.tvProductoMasRestado.text = "Sin movimientos esta semana"
                } else {
                    val productoTop = mapaProductos.maxByOrNull { it.value }?.key ?: "N/A"
                    binding.tvProductoMasRestado.text = productoTop
                }

            } catch (e: Exception) {
                Toast.makeText(this@DashboardActivity,
                    "Error al cargar dashboard", Toast.LENGTH_SHORT).show()
                e.printStackTrace()
            }
        }
    }

    override fun onSupportNavigateUp(): Boolean {
        finish()
        return true
    }
}