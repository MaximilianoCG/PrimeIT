package com.example.rodacleaninventario

import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.rodacleaninventario.databinding.ItemRestarProductoBinding

class RestarProductoAdapter(
    private val items: MutableList<ProductoARestar>,
    private val onCantidadChanged: () -> Unit
) : RecyclerView.Adapter<RestarProductoAdapter.ViewHolder>() {

    inner class ViewHolder(private val binding: ItemRestarProductoBinding) :
        RecyclerView.ViewHolder(binding.root) {

        fun bind(item: ProductoARestar) {
            binding.tvId.text = "ID: ${item.producto.id}"
            binding.tvNombre.text = item.producto.nombre

            binding.etCantidad.setText(item.cantidadARestar.toString())

            binding.etCantidad.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}

                override fun afterTextChanged(s: Editable?) {
                    val nuevaCantidad = s.toString().toIntOrNull() ?: 1
                    if (nuevaCantidad > 0 && nuevaCantidad <= item.producto.cantidad) {
                        item.cantidadARestar = nuevaCantidad
                        onCantidadChanged()
                    } else if (nuevaCantidad > item.producto.cantidad) {
                        binding.etCantidad.setText(item.producto.cantidad.toString())
                        item.cantidadARestar = item.producto.cantidad
                    }
                }
            })
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemRestarProductoBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(items[position])
    }

    override fun getItemCount(): Int = items.size

    fun getItemsToRestar(): List<ProductoARestar> = items.toList()
}